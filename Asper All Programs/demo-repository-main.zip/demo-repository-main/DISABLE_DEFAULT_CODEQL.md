# Disable Default CodeQL Setup

This guide explains how to disable the default CodeQL setup in your GitHub repository to allow only your advanced/custom CodeQL workflow to be active.

## Problem

When both a default CodeQL setup (configured via GitHub UI) and an advanced/custom CodeQL workflow (`.github/workflows/codeql.yml`) exist, they can conflict, causing upload and processing errors in your CI jobs.

## Solution: Disable Default CodeQL Setup

### Method 1: Via GitHub Web UI (Recommended)

1. **Navigate to your repository on GitHub:**
   - Go to: `https://github.com/Asper-Beauty-Shop/demo-repository`

2. **Access Code Scanning Settings:**
   - Click on the **"Security"** tab in your repository
   - Under **"Code scanning"**, you'll see the default CodeQL workflow

3. **Disable the Default Workflow:**
   - Find the default CodeQL workflow
   - Click **"Disable"** on the default CodeQL workflow
   - Confirm the action

4. **Alternative Path:**
   - Go to: **Settings** > **Code security and analysis** > **Code scanning**
   - Disable the default CodeQL setup from there

### Method 2: Via GitHub CLI (If Code Security is Enabled)

If Code Security is enabled for your repository, you can use the provided script:

```bash
./scripts/disable-default-codeql.sh
```

Or manually run:

```bash
gh api repos/Asper-Beauty-Shop/demo-repository/code-scanning/default-setup \
  -X PATCH \
  -f state=not_configured
```

**Note:** This method requires Code Security to be enabled for the repository. If you get a 403 error, use Method 1 instead.

## Verification

After disabling the default setup:

1. **Check that only your custom workflow is active:**
   - Go to **Actions** tab
   - Verify that only your `.github/workflows/codeql.yml` workflow appears
   - The default CodeQL workflow should no longer be listed

2. **Verify Code Scanning:**
   - Go to **Security** > **Code scanning alerts**
   - Ensure alerts are being processed by your advanced workflow only

## Important Notes

- **No changes to `.github/workflows/codeql.yml` are required** - your advanced workflow will continue to work as configured
- After disabling the default setup, your advanced workflow will be the only active CodeQL workflow
- This resolves upload and processing errors that occur when both workflows try to process results simultaneously

## Troubleshooting

If you encounter issues:

1. **Code Security not enabled:**
   - Enable it in: **Settings** > **Code security and analysis**
   - Then retry the disable operation

2. **Cannot find default setup:**
   - The default setup may not exist if it was never configured
   - In this case, only your custom workflow should be active

3. **Workflow conflicts persist:**
   - Ensure the default setup is completely disabled
   - Check that no other CodeQL workflows exist in `.github/workflows/` except your custom one

## Reference

- Your advanced CodeQL workflow: `.github/workflows/codeql.yml`
- Commit reference: `404d298d3526149a6275cf384e2a82403e17aab6`
