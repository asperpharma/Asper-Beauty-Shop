#!/bin/bash
# Script to disable the default CodeQL setup in GitHub repository
# This allows only the advanced/custom CodeQL workflow to be active

set -e

REPO_OWNER="Asper-Beauty-Shop"
REPO_NAME="demo-repository"

echo "Attempting to disable default CodeQL setup for ${REPO_OWNER}/${REPO_NAME}..."

# Method 1: Try to disable via API (requires Code Security to be enabled)
echo "Method 1: Attempting to disable via GitHub API..."
if gh api repos/${REPO_OWNER}/${REPO_NAME}/code-scanning/default-setup -X PATCH -f state=not_configured 2>/dev/null; then
    echo "✓ Successfully disabled default CodeQL setup via API"
    exit 0
else
    echo "✗ API method failed (Code Security may not be enabled or default setup doesn't exist)"
fi

# Method 2: Check if default workflow file exists and remove it
echo ""
echo "Method 2: Checking for default CodeQL workflow files..."
DEFAULT_WORKFLOWS=(
    ".github/workflows/codeql.yml"
    ".github/workflows/codeql-analysis.yml"
)

for workflow in "${DEFAULT_WORKFLOWS[@]}"; do
    if [ -f "$workflow" ]; then
        echo "Found default workflow: $workflow"
        echo "Note: This might be your custom workflow. Review before removing."
    fi
done

echo ""
echo "=========================================="
echo "MANUAL STEPS REQUIRED:"
echo "=========================================="
echo "Since automated methods may not work, please disable the default CodeQL setup manually:"
echo ""
echo "1. Go to your repository on GitHub:"
echo "   https://github.com/${REPO_OWNER}/${REPO_NAME}"
echo ""
echo "2. Navigate to: Security > Code scanning alerts"
echo ""
echo "3. Find the default CodeQL workflow and click 'Disable'"
echo ""
echo "4. Alternatively, go to: Settings > Code security and analysis > Code scanning"
echo "   and disable the default CodeQL setup there"
echo ""
echo "5. Ensure your advanced workflow (.github/workflows/codeql.yml) remains active"
echo ""
echo "After disabling, your advanced CodeQL workflow will be the only active one."
echo "=========================================="
