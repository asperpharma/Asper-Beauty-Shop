#!/bin/bash
# Script to display SSH public key for GitHub setup
# Run this script to get your public key to add to GitHub

set -e

SSH_KEY_PATH="$HOME/.ssh/id_ed25519_github"

echo "=========================================="
echo "GitHub SSH Key Setup"
echo "=========================================="
echo ""

if [ ! -f "$SSH_KEY_PATH.pub" ]; then
    echo "❌ SSH key not found at $SSH_KEY_PATH.pub"
    echo "Generating new SSH key..."
    ssh-keygen -t ed25519 -C "github-$(hostname)-$(date +%Y%m%d)" -f "$SSH_KEY_PATH" -N ""
    echo "✓ SSH key generated"
    echo ""
fi

echo "Your public SSH key:"
echo "----------------------------------------"
cat "$SSH_KEY_PATH.pub"
echo "----------------------------------------"
echo ""
echo "📋 Copy the key above and add it to GitHub:"
echo "   1. Go to: https://github.com/settings/keys"
echo "   2. Click 'New SSH key'"
echo "   3. Paste the key above"
echo "   4. Click 'Add SSH key'"
echo ""
echo "Test connection after adding:"
echo "   ssh -T git@github.com"
echo "=========================================="
