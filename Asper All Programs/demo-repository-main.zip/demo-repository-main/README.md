# Asper Beauty Shop

Premium beauty products catalog powered by [Apify](https://apify.com). This
static site fetches product data from an Apify dataset and displays it in a
beautiful, filterable product grid.

## Features

- **Live Product Data** — Fetches products from Apify dataset API in real-time
- **Product Grid** — Responsive grid layout with product images, prices, and
  variants
- **Filters & Search** — Filter by vendor, product type, and search by name
- **Product Details** — Shows images, prices (with compare-at pricing),
  variants, and links to product pages
- **Production Ready** — Includes meta tags, favicon, and GitHub Pages
  deployment workflow

## Run Locally

**Prerequisites:** Node.js 18+ and npm.

```bash
npm install
npm start
```

Then open [http://localhost:3000](http://localhost:3000). The site fetches
products from the Apify API endpoint.

## Publish to GitHub Pages

1. In your repo **Settings → Pages**, set **Source** to **GitHub Actions**.
2. Push to `main` (or manually trigger the "Deploy to GitHub Pages" workflow).
3. Your site will be published at
   `https://<org-or-user>.github.io/demo-repository/`.

## Data Source

Products are fetched from:

```
https://api.apify.com/v2/datasets/DmKvIKkvWSMdVFL38/items?format=csv&...
```

The site automatically:

- Parses the CSV response
- Groups products by productId (handling unwound variants/images)
- Displays products with images, prices, and variant information
- Provides filtering and search functionality

## GitHub Actions

- **`proof-html.yml`** — Validates HTML on push
- **`deploy-pages.yml`** — Deploys to GitHub Pages on push to main
- **`auto-assign.yml`** — Auto-assigns issues/PRs
