# Product Data

This directory contains product data files for the Asper Beauty Shop demo
repository.

## Files

### products-1-600.csv

This CSV file contains 600 sample beauty product entries with the following
columns:

- **ID**: Unique product identifier (1-600)
- **Product Name**: Name of the beauty product
- **Category**: Product category (Skincare, Makeup, Haircare, Fragrance, Bath &
  Body, Tools & Accessories)
- **Brand**: Brand name
- **Price**: Product price in USD
- **Stock**: Current stock quantity
- **Description**: Brief product description

This is sample data for demonstration purposes.
