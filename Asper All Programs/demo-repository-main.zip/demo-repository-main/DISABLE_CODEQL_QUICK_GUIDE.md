# Quick Guide: Disable Default CodeQL Setup

## 🎯 Step-by-Step Instructions

### Method 1: Via Security Tab (Recommended)

1. **Open your repository on GitHub:**
   ```
   https://github.com/Asper-Beauty-Shop/demo-repository
   ```

2. **Click on the "Security" tab**
   - Located in the top navigation bar of your repository
   - Between "Insights" and "Settings"

3. **Find "Code scanning" section**
   - Scroll down to the "Code scanning" section
   - You'll see alerts and workflows listed here

4. **Locate the default CodeQL workflow**
   - Look for a workflow named something like:
     - "CodeQL" (default)
     - "Code scanning: CodeQL"
     - Or any workflow that's NOT your custom `codeql.yml`

5. **Click "Disable" or "..." menu → "Disable"**
   - There should be a "Disable" button or a three-dot menu
   - Click it and confirm the action

### Method 2: Via Settings (Alternative)

1. **Go to Repository Settings:**
   - Click "Settings" tab (you need admin access)
   - Navigate to: **Code security and analysis**

2. **Find Code scanning section:**
   - Look for "Code scanning" under "Security"
   - Find the default CodeQL setup

3. **Disable it:**
   - Click "Disable" or toggle it off
   - Confirm the action

## ✅ Verification Steps

After disabling, verify it worked:

1. **Check Actions Tab:**
   - Go to **Actions** tab
   - You should only see your custom `.github/workflows/codeql.yml` workflow
   - The default CodeQL workflow should be gone

2. **Check Security Tab:**
   - Go back to **Security** → **Code scanning alerts**
   - Only your advanced workflow should be listed

3. **Test the Workflow:**
   - Make a small commit and push
   - Check Actions tab to see your custom CodeQL workflow run
   - Verify no conflicts or errors

## 🔍 What to Look For

**Before disabling:**
- You might see two CodeQL workflows
- One is the default (managed by GitHub)
- One is your custom `.github/workflows/codeql.yml`

**After disabling:**
- Only your custom workflow should remain
- No conflicts when running code scanning
- Clean workflow execution

## ⚠️ Important Notes

- **This is a one-time action** - Once disabled, the default setup won't interfere
- **Your custom workflow will continue working** - No changes needed to `codeql.yml`
- **You can re-enable later** - If needed, you can always re-enable the default setup
- **Requires repository admin access** - Make sure you have the right permissions

## 🆘 Troubleshooting

**Can't find the Security tab?**
- You might not have the right permissions
- Ask a repository admin to help

**Don't see a default CodeQL setup?**
- It might not be enabled
- Your custom workflow should work fine on its own
- Check Actions tab to verify

**Still seeing conflicts?**
- Make sure the default setup is completely disabled
- Check that only one CodeQL workflow exists in `.github/workflows/`
- Verify your custom workflow is properly configured

## 📞 Need Help?

If you encounter issues:
1. Check the `DISABLE_DEFAULT_CODEQL.md` for detailed instructions
2. Review GitHub's documentation on code scanning
3. Verify your repository permissions

---

**Once this is done, you're ready to merge!** 🚀
